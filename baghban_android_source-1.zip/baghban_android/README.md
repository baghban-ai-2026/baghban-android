# باغبان Android (source project)

این بسته **فایل APK آماده نیست**؛ سورس اندروید و سرور API است. برای ساخت APK به Android Studio و Android SDK نیاز دارید.

## سرور

```bash
cd server
python -m venv .venv
# Linux/macOS: source .venv/bin/activate
# Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
# set OPENAI_API_KEY in your environment (never commit it)
uvicorn main:app --host 0.0.0.0 --port 8000
```

سرور را روی هاست با HTTPS و آدرس عمومی مستقر کنید. در صورت دسترسی عمومی، **احراز هویت، محدودسازی درخواست‌ها و سهمیه مصرف** اضافه کنید؛ این نمونه آموزشی بدون احراز هویت است و نباید بدون حفاظت عمومی شود.

## اندروید

1. پوشه `android` را در Android Studio باز کنید؛ Gradle sync را انجام دهید (JDK 17 و Android SDK 35).
2. در `android/app/build.gradle.kts` مقدار `API_BASE_URL` را با آدرس HTTPS سرور خود عوض کنید (بدون `/chat`).
3. Build > Build Bundle(s) / APK(s) > Build APK(s) را بزنید.
4. خروجی debug معمولاً در `android/app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود؛ برای انتشار از signed release build استفاده کنید.
5. APK را به گوشی منتقل و نصب کنید.

## نکات

- حافظه مکالمه روی گوشی در SharedPreferences ذخیره می‌شود؛ رمزنگاری نشده و با پاک کردن داده‌های برنامه حذف می‌شود. فقط ۳۰ پیام آخر به مدل فرستاده می‌شود.
- صوت از سرویس تشخیص گفتار و TTS اندروید استفاده می‌کند؛ وجود صدای فارسی و پشتیبانی تشخیص گفتار بسته به گوشی/سرویس است.
- آواتار نسخه اولیه ایموجی متغیر است، نه تصویر سه‌بعدی.
- احساسات فقط برچسب‌های نمایشی مبتنی بر کلمات کلیدی‌اند.
- کد از نظر ساختار نوشته شده ولی در این محیط با Android SDK کامپایل/تست نشده است.
- کلید API فقط روی سرور نگهداری شود؛ هرگز در APK قرار ندهید.
