plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.baghban.ai"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.baghban.ai"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
        // Replace with your HTTPS server URL; never put an API key here.
        buildConfigField("String", "API_BASE_URL", "\"https://YOUR-SERVER.example.com\"")
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
