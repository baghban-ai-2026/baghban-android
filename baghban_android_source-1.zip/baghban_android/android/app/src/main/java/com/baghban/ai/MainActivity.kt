package com.baghban.ai

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var chat: LinearLayout
    private lateinit var input: EditText
    private lateinit var avatar: TextView
    private lateinit var send: Button
    private lateinit var scroll: ScrollView
    private var tts: TextToSpeech? = null
    private var voiceEnabled = true
    private val history = JSONArray()
    private val prefs by lazy { getSharedPreferences("baghban", MODE_PRIVATE) }
    private val speechRequest = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(20, 30, 20, 16)
            setBackgroundColor(Color.rgb(244, 250, 242))
        }
        avatar = TextView(this).apply { text = "🌱😊"; textSize = 50f; gravity = Gravity.CENTER }
        root.addView(avatar)
        root.addView(TextView(this).apply {
            text = "باغبان | دستیار گل و گیاه"; textSize = 22f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(25, 92, 43))
        })
        scroll = ScrollView(this)
        chat = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(chat)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        input = EditText(this).apply { hint = "درباره گیاهت بپرس…"; maxLines = 3 }
        bar.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        send = Button(this).apply { text = "ارسال"; setOnClickListener { sendMessage() } }
        bar.addView(send)
        root.addView(bar)
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply { text = "🎤 صحبت"; setOnClickListener { startSpeech() } }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply {
            text = "🔊 صدا روشن"
            setOnClickListener { voiceEnabled = !voiceEnabled; text = if (voiceEnabled) "🔊 صدا روشن" else "🔇 صدا خاموش" }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply {
            text = "پاک‌کردن"
            setOnClickListener { historyClear(); chat.removeAllViews(); avatar.text = "🌱😊" }
        }, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(actions)
        setContentView(root)
        val stored = prefs.getString("history", "[]") ?: "[]"
        try {
            val old = JSONArray(stored)
            for (i in 0 until old.length()) {
                val m = old.getJSONObject(i)
                history.put(m)
                bubble(m.optString("content"), m.optString("role") == "user")
            }
        } catch (_: Exception) { prefs.edit().remove("history").apply() }
        if (history.length() == 0) bubble("سلام! 🌿 من باغبانم. درباره گل و گیاه ازم بپرس.", false)
    }

    private fun bubble(message: String, user: Boolean) {
        val t = TextView(this).apply {
            text = (if (user) "شما: " else "باغبان: ") + message
            textSize = 16f
            setTextColor(Color.BLACK)
            setPadding(16, 14, 16, 14)
            setBackgroundColor(if (user) Color.rgb(215, 235, 255) else Color.rgb(219, 241, 214))
        }
        val p = LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 8) }
        chat.addView(t, p)
        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun persist() = prefs.edit().putString("history", history.toString()).apply()
    private fun historyClear() {
        while (history.length() > 0) history.remove(history.length() - 1)
        persist()
    }
    private fun sendMessage() {
        val question = input.text.toString().trim()
        if (question.isEmpty()) return
        input.setText("")
        bubble(question, true)
        history.put(JSONObject().put("role", "user").put("content", question))
        persist()
        send.isEnabled = false
        avatar.text = "🌱🤔"
        val snapshot = history.toString()
        thread {
            try {
                val connection = (URL(BuildConfig.API_BASE_URL.trimEnd('/') + "/chat").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 20000
                    readTimeout = 60000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                connection.outputStream.use { it.write(JSONObject().put("messages", JSONArray(snapshot)).toString().toByteArray(Charsets.UTF_8)) }
                val status = connection.responseCode
                val raw = (if (status in 200..299) connection.inputStream else connection.errorStream).bufferedReader().use { it.readText() }
                connection.disconnect()
                if (status !in 200..299) throw Exception("HTTP $status: $raw")
                val result = JSONObject(raw)
                val answer = result.getString("reply")
                val emotion = result.optString("emotion", "happy")
                runOnUiThread {
                    history.put(JSONObject().put("role", "assistant").put("content", answer))
                    persist()
                    bubble(answer, false)
                    avatar.text = when (emotion) { "concerned" -> "🌿😟"; "thinking" -> "🌱🤔"; "excited" -> "🌻😄"; else -> "🌱😊" }
                    if (voiceEnabled) tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "baghban-answer")
                    send.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    bubble("اتصال برقرار نشد: ${e.message}", false)
                    avatar.text = "🌿😟"
                    send.isEnabled = true
                }
            }
        }
    }

    private fun startSpeech() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 7)
            return
        }
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fa-IR")
                putExtra(RecognizerIntent.EXTRA_PROMPT, "درباره گل و گیاه صحبت کن")
            }
            startActivityForResult(intent, speechRequest)
        } catch (_: Exception) { Toast.makeText(this, "سرویس تشخیص گفتار روی گوشی موجود نیست", Toast.LENGTH_LONG).show() }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 7 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) startSpeech()
    }
    @Deprecated("Android speech intent callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == speechRequest && resultCode == RESULT_OK) {
            val words = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            if (!words.isNullOrEmpty()) input.setText(words[0])
        }
    }
    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale.forLanguageTag("fa-IR")
    }
    override fun onDestroy() { tts?.shutdown(); super.onDestroy() }
}
