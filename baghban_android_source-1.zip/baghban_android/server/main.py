import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="Baghban API")

class Message(BaseModel):
    role: str
    content: str

class ChatRequest(BaseModel):
    messages: list[Message] = Field(max_length=100)

SYSTEM = """تو باغبان هستی، دستیار فارسی‌زبان مهربان و صمیمی، متخصص فقط گل‌ها، گیاهان، خاک، آبیاری، آفات و باغبانی.
اگر سؤال خارج از این حوزه بود، محترمانه بگو فقط در مورد گل و گیاه کمک می‌کنی.
برای تشخیص مشکلات گیاه ابتدا درباره نور، آبیاری، خاک، دما و نشانه‌ها سؤال کن؛ در موارد نامطمئن قطعیت نشان نده.
برای استفاده از سموم خطرناک نسخه قطعی نده و به دستورالعمل برچسب و مقررات محلی ارجاع بده.
خودت را انسان معرفی نکن. پاسخ‌ها روشن و کاربردی باشند."""

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/chat")
def chat(req: ChatRequest):
    if not os.getenv("OPENAI_API_KEY"):
        raise HTTPException(500, "Server API key is missing")
    valid = [m.model_dump() for m in req.messages if m.role in ("user", "assistant") and m.content.strip()]
    if not valid or valid[-1]["role"] != "user":
        raise HTTPException(400, "Last message must be from user")
    if any(len(m["content"]) > 4000 for m in valid):
        raise HTTPException(400, "Message too long")
    try:
        response = OpenAI().responses.create(
            model=os.getenv("OPENAI_MODEL", "gpt-4.1-mini"),
            instructions=SYSTEM,
            input=valid[-30:],
            max_output_tokens=500,
        )
        reply = response.output_text.strip()
        # UI-only heuristic; not a claim about genuine emotions.
        latest = valid[-1]["content"]
        emotion = "concerned" if any(w in latest for w in ("بیمار", "زرد", "خشک", "آفت", "پوسیده")) else "excited" if any(w in latest for w in ("عالی", "گل داد", "رشد کرد")) else "happy"
        return {"reply": reply, "emotion": emotion}
    except Exception:
        raise HTTPException(502, "AI provider unavailable")
